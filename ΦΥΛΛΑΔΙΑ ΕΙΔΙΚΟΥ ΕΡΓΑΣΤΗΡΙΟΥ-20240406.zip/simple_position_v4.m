% Set the desired position
des_pos = 2;

%   The input setpoint is in Volts and can vary from 0 to 10 Volts because the position pot is refered to GND

V_7805=5.48;
Vref_arduino=5;


% clear
% delete(instrfind({'Port'},{'COM7'}));
% a = arduino;
a=arduino('COM3');

% OUTPUT ZERO CONTROL SIGNAL TO STOP MOTOR  %
analogWrite(a,6,0);
analogWrite(a,9,0);

% writePWMVoltage(a, 'D6', 0)
% writePWMVoltage(a, 'D9', 0)


positionData = [];
velocityData = [];
eData = [];
timeData = [];

t=0;

% CLOSE ALL PREVIOUS FIGURES FROM SCREEN

close all

% WAIT A KEY TO PROCEED
disp(['Connect cable from Arduino to Input Power Amplifier and then press enter to start controller']);
pause()



%START CLOCK
tic
 
 
while(t<5)  
    




velocity = analogRead(a,3);
position = analogRead(a,5);

% position = readVoltage(a, 'A5'); % position
% velocity = readVoltage(a,'A3'); % velocity

theta = 3 * Vref_arduino * position / 1023;
% theta = 3 * vref_arduino * position / 5;

vtacho = 2 * (2 * velocity * Vref_arduino / 1023 - V_7805);
% vtacho = 2 * (2 * velocity * vref_arduino / 5 - V7805);

 e = des_pos - theta;


 if(e > 255)
     e = 255;
 end
 
 if(e < -255)
     e = -255;
 end
 
% if abs(e) > 10
% 	e = sign(e) * 10;
% end



if e > 0
    analogWrite(a,6,0);
    analogWrite(a,9,min(round(e/2*255/ Vref_arduino) , 255));
    
%	writePWMVoltage(a, 'D6', 0)
%	writePWMVoltage(a, 'D9', abs(e) / 2)
else
    analogWrite(a,9,0);
    analogWrite(a,6,min(round(-e/2*255/ Vref_arduino) , 255));
  
%    writePWMVoltage(a, 'D9', 0)
%	writePWMVoltage(a, 'D6', abs(e) / 2)
end


t=toc;

    
timeData = [timeData t];
positionData = [positionData x1];
velocityData = [velocityData x2];
eData = [eData e];

end

% OUTPUT ZERO CONTROL SIGNAL TO STOP MOTOR  %
analogWrite(a,6,0);
analogWrite(a,9,0);

% writePWMVoltage(a, 'D6', 0)
% writePWMVoltage(a, 'D9', 0)

disp(['End of control Loop. Press enter to see diagramms']);
pause();


figure
plot(timeData,positionData);
title('position')

figure
plot(timeData,velocityData);
title('velocity')

figure
plot(timeData,eData);
title('error')

disp('Disonnect cable from Arduino to Input Power Amplifier and then press enter to stop controller');
pause();

